import pandas as pd
import numpy as np
from sklearn import tree
import math
from sklearn.model_selection import train_test_split

#import graphviz

# id,gender,age,hypertension,heart_disease,ever_married,work_type,Residence_type,avg_glucose_level,bmi,smoking_status,stroke,avg_gluc_age_ratio,bmi_age_ratio,bmi_gluc_ratio,past ind

#32069,Female,36,0,0,No,Govt_job,Urban,191.32,45.9,never smoked,0,5.314444444,1.275,4.168191721,0

df = pd.read_csv('all.csv')

df['gender'] = df['gender'].map({'Male': 1,
                                 'Female': -1,
                                 'Other': 0})
df['ever_married'] = df['ever_married'].map({'No': -1,
                                             'Yes': 1})
df['work_type'] = df['work_type'].map({value: idx for idx, value in enumerate(['children', 'Private', 'Never_worked', 'Self-employed', 'Govt_job'])})
df['Residence_type'] = df['Residence_type'].map({'Rural': -1, 'Urban': 1})
df['smoking_status'] = df['smoking_status'].map({math.nan: 0,
                                                 'never smoked': 1,
                                                 'formerly smoked': 2,
                                                 'smokes': 3})

    
X = df[['gender',
        'age',
        'hypertension',
        'ever_married',
        'work_type',
        'Residence_type',
        'avg_glucose_level',
        #'bmi',
        'smoking_status',
        'stroke',
        'avg_gluc_age_ratio',
        'bmi_age_ratio',]]
 #       'bmi_gluc_ratio',
#        'past ind']]

y = df['heart_disease']

# http://benalexkeen.com/decision-tree-classifier-in-python-using-scikit-learn/
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1)

# from sklearn import tree
# model = tree.DecisionTreeClassifier()

from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(n_estimators=200, max_depth=5)

model.fit(X_train, y_train)


y_predict = model.predict_proba(X_test)[:, 1]

from sklearn.metrics import roc_auc_score
auc = roc_auc_score(y_test, y_predict)

print ('AUC:', auc)

# from sklearn.metrics import accuracy_score
# print (accuracy_score(y_test, y_predict))

# from sklearn.metrics import precision_score
# print (precision_score(y_test, y_predict))

# from sklearn.metrics import recall_score
# print (recall_score(y_test, y_predict))

from sklearn.metrics import precision_recall_curve
precision, recall, thresholds = precision_recall_curve(y_test, y_predict)

best = None
for i in range(len(precision) - 1):
    if recall[i] > 0.70:
        if best is None or precision[i] > best[-2]:
            best = [i, thresholds[i], precision[i], recall[i]]
        #print ('%4d %0.2f %0.2f %0.2f' %  (i, thresholds[i], precision[i], recall[i]))

print (best)
