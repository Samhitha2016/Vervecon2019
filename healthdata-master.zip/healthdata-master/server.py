from flask import Flask
from flask import request
from flask import jsonify
from joblib import load
import pandas as pd

app = Flask(__name__)
model = load('model.joblib')

# {'responseId': 'c14af760-93e8-47bc-a3f7-1e0303ca5e99-bca4db85',
#  'queryResult': {
#      'queryText': '28',
#      'action': 'heart_issues',
#      'parameters': {
#          'Average_glucose-level': 0.4,
#          'Heart_disease': 'heart disease',
#          'gender': 'Male',
#          'work_type': 'Children',
#          'Residence_type': 'Urban',
#          'Smoking_status': 'smokes',
#          'marital_status': 'not married',
#          'Stroke': 'no',
#          'Age': 28.0
#      },
#      'allRequiredParamsPresent': True,
#      'intent': {
#          'name': 'projects/healthcare-assist/agent/intents/d5d0ed88-3123-4a27-8221-8c88f9eed2f5',
#          'displayName': 'heart_disease'
#      },
#      'intentDetectionConfidence': 1.0,
#      'languageCode': 'en'

#  }, 'originalDetectIntentRequest': {'payload': {}}, 'session': 'projects/healthcare-assist/agent/sessions/632d5b23-b73a-e335-c305-c9460a516cdd'}

import random

@app.route('/webhook', methods=['GET', 'POST'])
def hello_world():
    if random.random() < 0.5:
        return jsonify({'fulfillmentText': 'You might be at risk of heart disease'})
    else:
        return jsonify({'fulfillmentText': 'You are not at risk of heart disease'})
    
    features = request.get_json().get('queryResult').get('parameters')

    fv = {'avg_glucose_level': features['Average_glucose-level'],
          'gender': features['gender'],
          'work_type': features['work_type'],
          'Residence_type': features['Residence_type'],
          'smoking_status':  features['Smoking_status'],
          'ever_married': features['marital_status'],
#          'stroke': features['Stroke'],
          'age': features['Age']
    }
    fv['avg_gluc_age_ratio'] = fv['avg_glucose_level'] / fv['age']


    X = pd.DataFrame({k: [v] for k, v in fv.items()})
    
    for k in ('gender', 'ever_married', 'work_type', 'Residence_type', 'smoking_status'):
        X = pd.concat([X, pd.get_dummies(X[k], prefix=k)], axis=1)
        X.drop([k], axis=1, inplace=True)


    y_predict = model.predict_proba(X)[:, 1]
    print (y_predict)
    
    return jsonify({'fulfillmentText': 'This is a sample response'})
